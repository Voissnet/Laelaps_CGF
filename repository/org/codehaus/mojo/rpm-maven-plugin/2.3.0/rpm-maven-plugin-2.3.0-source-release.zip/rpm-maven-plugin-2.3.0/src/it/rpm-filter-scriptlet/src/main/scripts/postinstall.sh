#!/bin/sh

PROJECT_NAME=${project.artifactId}