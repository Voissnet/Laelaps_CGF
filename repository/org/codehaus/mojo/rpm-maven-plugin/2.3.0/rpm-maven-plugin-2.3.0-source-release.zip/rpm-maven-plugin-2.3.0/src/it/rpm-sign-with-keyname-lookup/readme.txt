To run a repeated test

  1. run full IT test first at Linux

  2. cd to target/it/rpm-sign-with-keyname-lookup, and invokde

     sh -x runtest.sh