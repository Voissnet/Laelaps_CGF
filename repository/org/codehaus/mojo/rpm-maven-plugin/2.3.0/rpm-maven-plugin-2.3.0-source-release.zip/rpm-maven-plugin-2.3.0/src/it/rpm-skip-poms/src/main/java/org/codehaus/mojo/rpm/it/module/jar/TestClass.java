package org.codehaus.mojo.rpm.it.module.jar;

public final class TestClass
{
    public TestClass()
    {
        System.out.println("some message");
    }
}